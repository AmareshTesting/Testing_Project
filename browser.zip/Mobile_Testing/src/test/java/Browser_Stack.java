import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;

public class Browser_Stack {

	public static AndroidDriver driver;
	public static final String UserName = "amareshsahoo_oZ1rKa";
	public static final String AutomateKey = "nChSot34CqRkrpeADpwe";
	//public static final String URL = "https://" + UserName + ":" + AutomateKey + "@hub-cloud.browserstack.com/wd/hub";

	@Test
	public void setup() throws MalformedURLException, InterruptedException {
		DesiredCapabilities cap = new DesiredCapabilities();

		cap.setCapability("deviceName", "Samsung Galaxy S23 Ultra");
		cap.setCapability("platformVersion", "13.0");
		cap.setCapability("platformName", "android");
		cap.setCapability("app", "bs://7fdecfb08ae0508df64e7a5718348840a8135d14");
		
		URL url=new URL("https://" + UserName + ":" + AutomateKey + "@hub-cloud.browserstack.com/wd/hub");
		driver=new AndroidDriver(url,cap);
		
		

		//Click Login Button on signup page
		Thread.sleep(10000);
		WebElement login=driver.findElement(By.id("com.unilever.regenerate.android.qa:id/landing_sign_in_button"));
		login.click();
		
		//Add the Email id
		Thread.sleep(5000);
		WebElement email=driver.findElement(By.xpath("//android.widget.EditText[@text='Enter email address']"));
		email.sendKeys("amaresh.sahoo@testunity.com");
		
		//Add Password
		Thread.sleep(5000);
		WebElement password=driver.findElement(By.xpath("//android.widget.EditText[@text='Enter password']"));
		password.sendKeys("Amaresh@1234");
		
		//Click signin signin page
		Thread.sleep(5000);
		WebElement signin=driver.findElement(By.xpath("//android.widget.TextView[@text='Sign in']"));
		signin.click();
		Thread.sleep(15000);
		

		//QUIT
		driver.quit();
		

	}

}
