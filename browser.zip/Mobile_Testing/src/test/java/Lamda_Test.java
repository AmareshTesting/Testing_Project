import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class Lamda_Test {

	public String username = "amaresh.sahoo";
	public String accesskey = "NHwPStmfHBxWlnqMPa1CtyNQW825sDSBxvtdokP8Jg45uthEtT";
	public static RemoteWebDriver driver = null;
	public String gridURL = "@hub.lambdatest.com/wd/hub";
	boolean status = false;

	@Test
	public void setUp() throws Exception {
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("platformName", "android");
		cap.setCapability("deviceName", "OnePlus 11");
		cap.setCapability("platformVersion", "13");
		cap.setCapability("isRealMobile", true);
		cap.setCapability("app", "bs://bf5e6616ea819adb1c32745acd3b2a4871be8324");

		driver = new RemoteWebDriver(new URL("https://" + username + ":" + accesskey + gridURL), cap);

		// Click Login Button on signup page
		Thread.sleep(10000);
		WebElement login = driver.findElement(By.id("com.unilever.regenerate.android.qa:id/landing_sign_in_button"));
		login.click();

		// Add the Email id
		Thread.sleep(5000);
		WebElement email = driver.findElement(By.xpath("//android.widget.EditText[@text='Enter email address']"));
		email.sendKeys("amaresh.sahoo@testunity.com");

		// Add Password
		Thread.sleep(5000);
		WebElement password = driver.findElement(By.xpath("//android.widget.EditText[@text='Enter password']"));
		password.sendKeys("Amaresh@1234");

		// Click signin signin page
		Thread.sleep(5000);
		WebElement signin = driver.findElement(By.xpath("//android.widget.TextView[@text='Sign in']"));
		signin.click();
		Thread.sleep(15000);

		// QUIT
		driver.quit();

	}
}
