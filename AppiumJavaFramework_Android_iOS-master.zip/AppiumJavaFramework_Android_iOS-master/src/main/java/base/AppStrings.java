package base;

public class AppStrings {

}
