import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Login {
		
		public static AndroidDriver driver;
		
		public static void main(String[] args) throws MalformedURLException, InterruptedException {
			
			DesiredCapabilities cap=new DesiredCapabilities();
			cap.setCapability(MobileCapabilityType.AUTOMATION_NAME,"UiAutomator2");
			cap.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
			cap.setCapability(MobileCapabilityType.PLATFORM_VERSION,"11.0");
			cap.setCapability(MobileCapabilityType.DEVICE_NAME,"Android Emulator");
			cap.setCapability(MobileCapabilityType.APP, "D:\\Test Unity\\Session\\Mobile Testing\\Leap Rewards.apk");
			
			URL url=new URL("http://127.0.0.1:4723/wd/hub/");
			
			driver=new AndroidDriver(url,cap);
			Thread.sleep(15000);
			
			//Click Login Button on signup page
			Thread.sleep(10000);
			WebElement login=driver.findElement(By.id("com.unilever.regenerate.android.qa:id/landing_sign_in_button"));
			login.click();
			
			//Add the Email id
			Thread.sleep(5000);
			WebElement email=driver.findElement(By.xpath("//android.widget.EditText[@text='Enter email address']"));
			email.sendKeys("amaresh.sahoo@testunity.com");
			
			//Add Password
			Thread.sleep(5000);
			WebElement password=driver.findElement(By.xpath("//android.widget.EditText[@text='Enter password']"));
			password.sendKeys("Amaresh@1234");
			
			//Click signin signin page
			Thread.sleep(5000);
			WebElement signin=driver.findElement(By.xpath("//android.widget.TextView[@text='Sign in']"));
			signin.click();
			Thread.sleep(15000);
			
			
			
			//driver.quit();
			

		}

}
