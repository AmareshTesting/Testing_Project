import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.net.MalformedURLException;
import java.net.URL;

public class Lambda_MobileApp {

	public static String userName = System.getenv("amaresh.sahoo") == null ? "amaresh.sahoo" // Add LambdaTest username here
			: System.getenv("amaresh.sahoo");
	public static String accessKey = System.getenv("NHwPStmfHBxWlnqMPa1CtyNQW825sDSBxvtdokP8Jg45uthEtT") == null ? "NHwPStmfHBxWlnqMPa1CtyNQW825sDSBxvtdokP8Jg45uthEtT" // Add LambdaTest
																								// accessKey here
			: System.getenv("NHwPStmfHBxWlnqMPa1CtyNQW825sDSBxvtdokP8Jg45uthEtT");

	private static AppiumDriver driver;

	public static void main(String args[]) throws MalformedURLException, InterruptedException {

		try {
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability("deviceName", "Galaxy S20");
			capabilities.setCapability("platformVersion", "11");
			capabilities.setCapability("platformName", "Android");
			capabilities.setCapability("isRealMobile", true);
			capabilities.setCapability("app", "APP_URL"); // Enter your app url
			capabilities.setCapability("deviceOrientation", "PORTRAIT");
			capabilities.setCapability("build", "Java Vanilla - Android");
			capabilities.setCapability("name", "Sample Test Java");
			capabilities.setCapability("console", true);
			capabilities.setCapability("network", false);
			capabilities.setCapability("visual", true);
			capabilities.setCapability("devicelog", true);

			driver = new AppiumDriver(
					new URL("https://" + userName + ":" + accessKey + "@mobile-hub.lambdatest.com/wd/hub"),
					capabilities);

		} catch (AssertionError a) {
			((JavascriptExecutor) driver).executeScript("lambda-status=failed");
			a.printStackTrace();
		}
// The driver.quit statement is required, otherwise the test continues to execute, leading to a timeout.
		driver.quit();
	}
}
