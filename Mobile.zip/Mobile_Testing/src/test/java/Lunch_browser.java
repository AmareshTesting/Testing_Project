import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;

public class Lunch_browser {

	public static AndroidDriver driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		
		DesiredCapabilities cap=new DesiredCapabilities();
		
		cap.setCapability("VERSION", "11.0");
		cap.setCapability("deviceName", "Android Emulator");
		cap.setCapability("platformName", "Android");
		cap.setCapability("browserName", "Chrome");
		//cap.setCapability("chromedriverExecutable", "D:\\Test Unity\\Session\\Mobile Testing\\selenium-chrome-driver-4.10.0.jar");
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub/");

		driver = new AndroidDriver(url, cap);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(1000));
		
		Thread.sleep(10000);
		driver.get("https://www.google.com/");
		

	}

}
