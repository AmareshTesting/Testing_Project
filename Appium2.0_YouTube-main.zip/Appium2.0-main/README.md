# Appium2.0
Latest Appium Client Code including Gestures

Download apps from here

https://github.com/saucelabs/my-demo-app-rn/releases

https://github.com/appium/android-apidemos/releases

**Youtube Tutorials**

https://www.youtube.com/watch?v=jQFRgOI8-3o&list=PL9ok7C7Yn9A99LiTcemmKmupBdNB38bbo
