import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
 
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
 
public class demo2 {
 
    public String username = "amaresh.sahoo";
    public String accesskey = "NHwPStmfHBxWlnqMPa1CtyNQW825sDSBxvtdokP8Jg45uthEtT";
    public RemoteWebDriver driver = null;
    public String gridURL = "@hub.lambdatest.com/wd/hub";
    boolean status = false;
    
    @BeforeMethod
    @Parameters(value={"browser","version","platform"})
    public void setUp(String browser, String version, String platform) throws Exception {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("browserName", browser);
        capabilities.setCapability("version", version);
        capabilities.setCapability("platform", platform); // If this cap isn't specified, it will just get the any available one
        capabilities.setCapability("build", "ParallelTestNG");
        capabilities.setCapability("name", "ParallelTestNG");
        capabilities.setCapability("network", true); // To enable network logs
        capabilities.setCapability("visual", true); // To enable step by step screenshot
        capabilities.setCapability("video", true); // To enable video recording
        capabilities.setCapability("console", true); // To capture console logs
        try {
            driver = new RemoteWebDriver(new URL("https://" + username + ":" + accesskey + gridURL), capabilities);
        } catch (MalformedURLException e) {
            System.out.println("Invalid grid URL");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    @Test
    public void Test() {
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    	driver.get("https://phptravels.com/demo/");

     driver.findElement(By.name("first_name")).sendKeys("Pooja", Keys.ENTER);
     driver.findElement(By.name("last_name")).sendKeys("Singh", Keys.ENTER);
    driver.findElement(By.name("business_name")).sendKeys("Test Unity", Keys.ENTER);
     driver.findElement(By.name("email")).sendKeys("pooja@gmail.com", Keys.ENTER);


    	String value1= driver.findElement(By.xpath("//*[@id=\"numb1\"]")).getText();
    	 String value2= driver.findElement(By.xpath("//*[@id=\"numb2\"]")).getText();
    	  System.out.println(value1);
       System.out.println(value2);
    	  int number=Integer.parseInt(value1)+Integer.parseInt(value2);
    	  String numberValue=Integer.toString(number);
    	 System.out.println(numberValue);
    	 driver.findElement(By.id("number")).sendKeys(numberValue, Keys.ENTER);
    	driver.findElement(By.id("demo")).click();
    }
 
    @AfterMethod
    public void tearDown() throws Exception {
        if (driver != null) {
            System.out.println("Tearing down..");
            driver.quit();
        }
    }
}