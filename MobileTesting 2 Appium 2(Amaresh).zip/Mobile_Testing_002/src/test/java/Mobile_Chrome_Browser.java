import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class Mobile_Chrome_Browser {
	
public static AndroidDriver driver;
	
	@Test
	public void chromeBrowser() throws MalformedURLException, InterruptedException {
		UiAutomator2Options options = new UiAutomator2Options(); 
		options.setAutomationName("UiAutomator2");
		options.setPlatformName("Android");
		options.setDeviceName("Pixel 4 API 30");
		//For chrome driver
		options.withBrowserName("Chrome");

		URL url = new URL("http://127.0.0.1:4723/");
		driver=new AndroidDriver(url, options);
		
		driver.get("https://testunity.com/");
		//Thread.sleep(2000);
		
		//click hamburger
		driver.findElement(By.xpath("//button[@class=\"menu-mobile-trigger\"]")).click();
		//click Contact
		driver.findElement(By.xpath("//a[text()=\"CONTACT\"]")).click();
		//enter name
		driver.findElement(By.xpath("//input[@placeholder=\"Full Name\"]")).sendKeys("Amaresh Sahoo");
	    
	}

}
