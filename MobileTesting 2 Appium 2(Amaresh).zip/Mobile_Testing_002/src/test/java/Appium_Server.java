import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class Appium_Server {
	
	static AppiumDriverLocalService server;
	
	static void setInstance() {
		
		//Set the path
		String nodeJSMainPath="C:\\Users\\Amaresh Sahoo\\AppData\\Roaming\\npm\\node_modules\\appium\\build\\lib\\main.js";
		String nodeExePath="C:\\Program Files\\nodejs\\node.exe";
	    String logFilePath="C:\\Users\\Amaresh Sahoo\\eclipse-workspace\\Mobile_Testing_002\\Log\\log.txt";
		
		AppiumServiceBuilder builder=new AppiumServiceBuilder();
		
		builder
		.withAppiumJS(new File(nodeJSMainPath))
		.usingDriverExecutable(new File(nodeExePath))
		.usingPort(4723)
		.withLogFile(new File(logFilePath))
		.withArgument(GeneralServerFlag.LOCAL_TIMEZONE)
		.withIPAddress("127.0.0.1");
		
		server= AppiumDriverLocalService.buildService(builder);
	}
	
	//To check whether the server is already running
	static AppiumDriverLocalService getInstance() {
		if(server == null) {
			setInstance();
		}
		return server;
	} 
	
	public static void startAppiumServer() {
		getInstance().start();
		System.out.println("Starting Appium Server-----------------------------");
		System.out.println("URL: " + server.getUrl());
		System.out.println("Is the server running: " + server.isRunning());
	}
	
	public static void stopAppiumServer() {
		
			if(server!= null) {
				getInstance().stop();
			}
			System.out.println("Stopped Appium Server----------------------------");
	}
	
	public static void main(String[] args) throws MalformedURLException {
		
		Appium_Server.startAppiumServer();
		
		UiAutomator2Options options = new UiAutomator2Options();
		 
		options.setAutomationName("UiAutomator2");
		options.setPlatformName("Android");
		options.setDeviceName("Pixel 4 API 30");
		options.setApp("D:\\Test Unity\\Session\\Mobile Testing\\Android-MyDemoAppRN.1.3.0.build-244.apk");


		//URL url = new URL("http://127.0.0.1:4723/");// No need to add URL
		AndroidDriver driver = new AndroidDriver(options);
		//AndroidDriver driver = new AndroidDriver(new URL("http://192.168.1.4:4723/"),options);
		
		
		Appium_Server.startAppiumServer();
		System.out.println("End--------------------------");
		

	}

}
