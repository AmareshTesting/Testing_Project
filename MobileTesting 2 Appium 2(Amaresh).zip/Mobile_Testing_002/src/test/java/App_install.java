import java.net.MalformedURLException;
import java.net.URL;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.remote.AutomationName;

public class App_install {

	@Test
	public void appInstall() throws MalformedURLException {

		UiAutomator2Options options = new UiAutomator2Options();

		// options.setAutomationName(AutomationName.ANDROID_UIAUTOMATOR2);
		// If you do not set the Automation name and Platform name, it'll take it by default.
		 
		options.setAutomationName("UiAutomator2");
		options.setPlatformName("Android");

		// We have to added the device name. If one device is connected we can give any random name.
		options.setDeviceName("Pixel 4 API 30");

		// We can add the app path from he project directory. To add the app just drag and drop
		options.setApp("D:\\Test Unity\\Session\\Mobile Testing\\Android-MyDemoAppRN.1.3.0.build-244.apk");

		URL url = new URL("http://127.0.0.1:4723/");
		AndroidDriver driver = new AndroidDriver(url, options);

		// AndroidDriver driver = new AndroidDriver(new URL("http://192.168.1.4:4723/"),options);	

	}

}
