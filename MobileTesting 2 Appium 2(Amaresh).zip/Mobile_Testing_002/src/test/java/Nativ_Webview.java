import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class Nativ_Webview {
	
public static AndroidDriver driver;
	
	@Test
	public void nativWebView() throws MalformedURLException, InterruptedException {
		UiAutomator2Options options = new UiAutomator2Options(); 
		options.setAutomationName("UiAutomator2");
		options.setPlatformName("Android");
		options.setDeviceName("Pixel 4 API 30");
		options.setApp("D:\\Test Unity\\Session\\Mobile Testing\\android.wdio.native.app.v1.0.8.apk");

		URL url = new URL("http://127.0.0.1:4723/");
		driver=new AndroidDriver(url, options);
		
		//Find the current context and all the context handles
		System.out.println("Current context: " + driver.getContext());
		System.out.println("Current handles: " + driver.getContextHandles());
		
		//Clicked the web view
		Thread.sleep(2000);
		driver.findElement(AppiumBy.accessibilityId("Webview")).click();
		
		//Now we'll get both native and web context
		Thread.sleep(2000);
		System.out.println("Current handles: " + driver.getContextHandles());
		
		//Get all the context handles
		Set<String> handles= driver.getContextHandles();
		String webContext= new ArrayList<String>(handles).get(1);
		System.out.println("Fetch the web context: " + webContext);
		
		//Switch Native to Web view
		driver.context(webContext);
		Thread.sleep(2000);
		//Web Operation
		//driver.findElement(By.xpath("//button[@class=\"navbar__toggle clean-btn\"]")).click();
		//driver.findElement(By.xpath("//button[@class=\"clean-btn navbar-sidebar__close\"]")).click();
		//driver.findElement(By.xpath("//a[text()=\"Get Started\"]")).click();
		
		//Switch web to native view
		driver.context("NATIVE_APP");//Get it from console
		
		//Clicked the Login
		Thread.sleep(1000);
	    driver.findElement(AppiumBy.accessibilityId("Login")).click();
	    Thread.sleep(1000);
	    driver.findElement(AppiumBy.accessibilityId("input-email")).sendKeys("amaresh.sahoo@testunity.com");
	    
	}

}
