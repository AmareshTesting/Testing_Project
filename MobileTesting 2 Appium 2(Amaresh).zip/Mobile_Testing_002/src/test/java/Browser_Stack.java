import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class Browser_Stack {
	
	public static AndroidDriver driver;
	public static final String UserName = "amareshsahoo_oZ1rKa";
	public static final String AutomateKey = "nChSot34CqRkrpeADpwe";
	//public static final String URL = "https://" + UserName + ":" + AutomateKey + "@hub-cloud.browserstack.com/wd/hub";

	@Test
	public void appInstall() throws MalformedURLException {

		UiAutomator2Options options = new UiAutomator2Options();

		options.setPlatformName("Android");
		options.setPlatformVersion("13.0");
		options.setDeviceName("Samsung Galaxy S23 Ultra");
		options.setApp("bs://acc2e2fc3bc6fd2b77e89b8c434a78ad1ca9ebf9");

		URL url=new URL("https://" + UserName + ":" + AutomateKey + "@hub-cloud.browserstack.com/wd/hub");
		AndroidDriver driver = new AndroidDriver(url, options);
		
		WebElement openMenu =driver.findElement(AppiumBy.accessibilityId("open menu"));
		openMenu.click();
		//tap(openMenu); //We can use tab by extending the class
		WebElement drawng =driver.findElement(AppiumBy.accessibilityId("menu item drawing"));
		drawng.click();
		//tap(drawng);
	    WebElement element = driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"drawing screen\"]"));
	    Point centerOfElement = getCenterOfElement(element.getLocation(), element.getSize());

	    PointerInput finger1 = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
	    PointerInput finger2 = new PointerInput(PointerInput.Kind.TOUCH, "finger2");
	    Sequence sequence = new Sequence(finger1, 1)
	        .addAction(finger1.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), centerOfElement))
	        .addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	        .addAction(new Pause(finger1, Duration.ofMillis(200)))
	        .addAction(finger1.createPointerMove(Duration.ofMillis(200),
	                                             PointerInput.Origin.viewport(), centerOfElement.getX() + 100,
	                                             centerOfElement.getY() - 100))
	        .addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

	    Sequence sequence2 = new Sequence(finger2, 1)
	        .addAction(finger2.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), centerOfElement))
	        .addAction(finger2.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	        .addAction(new Pause(finger2, Duration.ofMillis(200)))
	        .addAction(finger2.createPointerMove(Duration.ofMillis(200),
	                                             PointerInput.Origin.viewport(), centerOfElement.getX() - 100,
	                                             centerOfElement.getY() + 100))
	        .addAction(finger2.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

	    driver.perform(Arrays.asList(sequence, sequence2));
	    
	    driver.quit();
	}
	//We created this method for "getCenterOfElement"
	private Point getCenterOfElement(Point location, Dimension size) {
		return new Point(location.getX()+size.getWidth()/2,location.getY()+size.getHeight()/2);
		
	}
	
}
