import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Collections;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class Drag_and_Drop {

	public static AndroidDriver driver;

	@Test
	public void Drag_Drop() throws MalformedURLException {
		UiAutomator2Options options = new UiAutomator2Options();
		options.setAutomationName("UiAutomator2");
		options.setPlatformName("Android");
		options.setDeviceName("Pixel 4 API 30");
		options.setAppPackage("com.touchboarder.android.api.demos");
		options.setAppActivity("com.example.android.apis.ApiDemos");
		options.setNoReset(true);
		options.setFullReset(false);
		// options.setApp("D:\\Test Unity\\Session\\Mobile Testing\\API Demos for
		// Android.apk");

		URL url = new URL("http://127.0.0.1:4723/");
		driver = new AndroidDriver(url, options);

		driver.findElement(AppiumBy.xpath(".//*[@text='Views']")).click();
		driver.findElement(AppiumBy.xpath(".//*[@text='Drag and Drop']")).click();

		WebElement source = driver.findElement(AppiumBy.id("com.touchboarder.android.api.demos:id/drag_dot_1"));
		WebElement target = driver.findElement(AppiumBy.id("com.touchboarder.android.api.demos:id/drag_dot_2"));

		// Point is basically a coordinate(Combination of x and y)
		Point sourceElementCenter = getCenterOfElement(source.getLocation(), source.getSize());
		Point targetElementCente = getCenterOfElement(target.getLocation(), target.getSize());

		// Drag and Drop_Action
		PointerInput finger1 = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
		Sequence sequence = new Sequence(finger1, 1)
				.addAction(finger1.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), sourceElementCenter))
				.addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
				.addAction(new Pause(finger1, Duration.ofMillis(500)))
		        .addAction(finger1.createPointerMove(Duration.ofMillis(500), PointerInput.Origin.viewport(), targetElementCente))
		        .addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));		

		driver.perform(Collections.singletonList(sequence));

	}

	// We created this method for "getCenterOfElement"
	private Point getCenterOfElement(Point location, Dimension size) {
		return new Point(location.getX() + size.getWidth() / 2, location.getY() + size.getHeight() / 2);

	}

}
